/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author student
 */
public class Main extends Application {

    Button btn = new Button("Run");
    CheckBox checkBox = new CheckBox("Custom");
    TextField txtForN = new TextField();
    TextField txtForR = new TextField();
    TextField txtForC = new TextField();

    @Override
    public void start(Stage primaryStage) {

        BorderPane root = new BorderPane();
        btn.setAlignment(Pos.CENTER);
        checkBox.setAlignment(Pos.CENTER);

        txtForN.setPrefWidth(70);
        txtForR.setPrefWidth(70);
        txtForC.setPrefWidth(70);
        txtForN.setPromptText("Set N");
        txtForR.setPromptText("Set R");
        txtForC.setPromptText("Set C");
        txtForR.setDisable(true);
        txtForC.setDisable(true);

        HBox root3 = new HBox(txtForN, txtForR, txtForC);
        root3.setAlignment(Pos.CENTER);
        root3.setSpacing(10);
        root3.setPadding(new Insets(20));

        VBox root2 = new VBox(checkBox, root3, btn);
        root2.setAlignment(Pos.CENTER);

        root.setCenter(root2);

        Scene scene = new Scene(root, 300, 250);

        primaryStage.setTitle("Eight_Queen_Problem");
        primaryStage.setScene(scene);
        primaryStage.show();

        checkBox.selectedProperty().addListener((e) -> {
            if (checkBox.isSelected()) {
                txtForR.setDisable(false);
                txtForC.setDisable(false);
            } else {
                txtForR.setDisable(true);
                txtForC.setDisable(true);
            }
        });
        btn.setOnAction((e) -> {
            primaryStage.close();
            if (checkBox.isSelected()) {
                int n = Integer.parseInt(txtForN.getText());
                int r = Integer.parseInt(txtForR.getText());
                int c = Integer.parseInt(txtForC.getText());
                if (n < 4 || r<1 || r>n || c<1 || c>n ) {
                    System.out.println("Error: Greska u unosu.");
                } else {
                    new EightQueenProblem2(n, r - 1, c - 1);
                }
            } else {
                int n = Integer.parseInt(txtForN.getText());
                if(n>3){
                    new EightQueenProblem(n);
                }
                else System.out.println("Error: N mora biti najmanje 4.");
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
