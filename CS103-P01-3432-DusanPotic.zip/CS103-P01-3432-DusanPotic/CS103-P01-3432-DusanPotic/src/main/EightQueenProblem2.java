/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Border;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

/**
 *
 * @author student
 */
public class EightQueenProblem2 extends Stage {

    int n = 8;//default
    int r = 0;//default
    int c = 0;//default
    
    GridPane root = new GridPane();
    Image slika = new Image("http://chittagongit.com//images/queen-icon/queen-icon-14.jpg");

    public EightQueenProblem2() {
        iscrtajTablu();
        resiProblem(n, r, c);
        setScene();
    }

    public EightQueenProblem2(int n, int r, int c) {
        setN(n);
        setR(r);
        setC(c);
        iscrtajTablu();
        resiProblem(getN(), getR(), getC());
        setScene();
    }

    public final void iscrtajTablu() {
        
        //kolone
        for (int i = 0; i < n; i++) {
            ColumnConstraints colConst = new ColumnConstraints();
            colConst.setPercentWidth(100.0 / n);
            root.getColumnConstraints().add(colConst);
        }
        //redovi
        for (int i = 0; i < n; i++) {
            RowConstraints rowConst = new RowConstraints();
            rowConst.setPercentHeight(100.0 / n);
            root.getRowConstraints().add(rowConst);
        }
        //boja polja
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                Rectangle rect = new Rectangle();
                if (i % 2 != 0 && j % 2 == 0 || i % 2 == 0 && j % 2 != 0) {
                    rect.setFill(Color.rgb(129, 129, 140));
                } else {
                    rect.setFill(Color.WHITE);
                }
                rect.widthProperty().bind(root.widthProperty().divide(n));
                rect.heightProperty().bind(root.heightProperty().divide(n));
                root.add(rect, i, j);
            }
        }
    }

    void printBoard(int board[][]) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                System.out.print(" " + board[i][j] + " ");
                if (board[i][j] == 1) {
                    //ubaci sliku kraljice
                    ImageView queen = new ImageView(slika);
                    queen.setFitHeight(20);
                    queen.setFitWidth(20);
                    root.add(queen, j, i);
                }
            }
            System.out.println();
        }
    }

    boolean checkIsValid(int board[][], int row, int col) {
        //leva dijagonala
        for (int i = row, j = col; i >= 0 && j >= 0; i--, j--) {
            if (board[i][j] == 1) {
                return false;
            }
        }
        //desna dijagonala
        for (int i = row, j = col; i >= 0 && j < board.length; i--, j++) {
            if (board[i][j] == 1) {
                return false;
            }
        }
        //desna dijagonala2
        for (int i = row, j = col; i < board.length && j < board.length; i++, j++) {
            if (board[i][j] == 1) {
                return false;
            }
        }
        //leva dijagonala2
        for (int i = row, j = col; i < board.length && j >= 0; i++, j--) {
            if (board[i][j] == 1) {
                return false;
            }
        }
        //vertikalno
        for (int j = 0; j < board.length; j++) {
            if (board[row][j] == 1) {
                return false;
            }
        }
        //horizontalno
        for (int i = 0; i < board.length; i++) {
            if (board[i][col] == 1) {
                return false;
            }
        }
        return true;
    }

    boolean pretrazi(int board[][], int row) {
        if (row >= board.length) {
            return true;
        }
        if (row == r) {
            return true;
        }
        for (int i = 0; i < board.length; i++) {
            System.out.println("try " + row + " " + i);
            if (checkIsValid(board, row, i)) {
                System.out.println("place ");
                board[row][i] = 1;
                if (row + 1 == r) {
                    if (pretrazi(board, row + 2) == true) {
                        return true;
                    }
                } else if (pretrazi(board, row + 1) == true) {
                    return true;
                }
                board[row][i] = 0;
                System.out.println("back from" + row + " " + i);
            }
        }
        return false;
    }

    final void resiProblem(int n, int r, int c) {
        int board[][] = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                board[i][j] = 0;
            }
        }
        board[r][c] = 1;
        if (r == 0) {
            if (pretrazi(board, 1) == false) {
                System.out.println("Nemoguce resenje");
            }
        } else if (pretrazi(board, 0) == false) {
            System.out.println("Nemoguce resenje");
        }
        printBoard(board);
    }

    public final void setScene() {
        root.setBorder(Border.EMPTY);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 500, 500);

        this.setTitle("Eight_Queen_Problem_Custom");
        this.setScene(scene);
        this.show();
    }

    public final int getN() {
        return n;
    }

    public final void setN(int n) {
        this.n = n;
    }

    public final int getR() {
        return r;
    }

    public final void setR(int r) {
        this.r = r;
    }

    public final int getC() {
        return c;
    }

    public final void setC(int c) {
        this.c = c;
    }
}
